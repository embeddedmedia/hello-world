import numpy as np
from PIL import Image as im

array_in = np.loadtxt("input.data", dtype="uint8")
array_out = np.loadtxt("output.data", dtype="uint8")

array_in = np.reshape(array_in, (128, 128))
array_out = np.reshape(array_out, (128, 128))

data = im.fromarray(array_in)
data.save('input.png')

data = im.fromarray(array_out)
data.save('output.png')