#include <stdlib.h>
#include <stdint.h>
#include "xremap_accel.h"
#include "xparameters.h"
#include "remap_input_image.h"
#include "remap_x_map.h"
#include "remap_y_map.h"

//pull in external arrays
extern unsigned int remap_input_image[16384];
extern float remap_x_map[16384];
extern float remap_y_map[16384];

//define device ID from xparameters.h
#define XREMAP_DEVICE_ID XPAR_REMAP_ACCEL_0_DEVICE_ID

//define image size
#define PIXEL_COUNT 16384
#define ROWS 0x80 //128
#define COLS 0x80 //128

int main()
{
	//remap IP instance from HLS API
	//https://docs.xilinx.com/r/en-US/ug1399-vitis-hls/Vitis-HLS-C-Driver-Reference
	XRemap_accel remapAccel;
	//configuration pointer for the IP
	XRemap_accel_Config *Config;

	//configure and initialize the device
	Config = XRemap_accel_LookupConfig(XREMAP_DEVICE_ID);
	if (NULL == Config) {
		return XST_FAILURE;
	}
	int Status = XRemap_accel_CfgInitialize(&remapAccel, Config);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	//set the amount of ROWS and COLS to process in the remap IP based on the image
	XRemap_accel_Set_rows(&remapAccel, ROWS );
	XRemap_accel_Set_cols(&remapAccel, COLS);

	//assign addresses to store array data in memory
	//this location can be anywhere within the scope of the address map in Vivado
	u64* input_buffer = (u64*) 0x10a00000;
	float* x_buffer = (u64*) 0x10b00000;
	float* y_buffer = (u64*) 0x10c00000;
	u64* output_buffer = (u64*) 0x10d00000;

	//pre-clear out memory to ensure IP is writing to empty locations
	//0xac is used to visualize that the memory has been overwritten,
	//it can be changed to any sequence or 0x0
	memset(input_buffer, 0xac, PIXEL_COUNT);
	memset(x_buffer, 0xac, PIXEL_COUNT);
	memset(y_buffer, 0xac, PIXEL_COUNT);
	memset(output_buffer, 0xac, PIXEL_COUNT);

	//for vision functions, the input pixels must be packed as 8 pixels
	//in 64-bits with nearest address occupying LSB byte format (left to right)
	//this is normally automataically handled in an acceleration flow,
	//but for embedded applications the data has to be properly formatted
	int i = 0;
	for (i = 0; i < PIXEL_COUNT; i += 8) {
		u64 temp_64 = 0, temp_1_32 = 0, temp_2_32 = 0, count = 0;
   		for (int j = i, k = 0; j < i+8; j++, k += 8, count += 8) {
   			if (k == 32){
				count = 0;
			}
   			if (k <= 24){
				temp_1_32 = temp_1_32 | ((unsigned char) remap_input_image[j] << k) ;
   			}else{
   				temp_2_32 = temp_2_32 | ((unsigned char) remap_input_image[j] << count);
   			}
   		}
   		temp_1_32 = (temp_1_32 & 0x00000000ffffffff);
   		u64 temp_64_1 = (temp_2_32 << 32);
   		temp_64 = temp_64_1 | temp_1_32 ;
   		input_buffer[i / 8] = temp_64;
   	}

	//send the x_map and y_map data to the memory
   	for(i = 0; i < PIXEL_COUNT; i++) {
   		x_buffer[i] = remap_x_map[i];
   		y_buffer[i] = remap_y_map[i];
   	}

   	//this ensures the processor reads/writes from the DDR instead of the cache
   	Xil_DCacheInvalidate();

   	//set up IP arguments with appropriate memory locations to write to
   	XRemap_accel_Set_img_in(&remapAccel, input_buffer);
   	XRemap_accel_Set_map_x(&remapAccel, x_buffer);
   	XRemap_accel_Set_map_y(&remapAccel, y_buffer);
   	XRemap_accel_Set_img_out(&remapAccel, output_buffer);

   	//wait for the IP to be ready and idle before processing data
	while (!(XRemap_accel_IsIdle(&remapAccel) && XRemap_accel_IsReady(&remapAccel))) {}

	//start the IP
	XRemap_accel_Start(&remapAccel) ;

	//wait for valid data output via IsDone API
	//the out_address can then be passed to other parts of a full design
	u64 out_address = 0;
	do {
		out_address = XRemap_accel_Get_img_out(&remapAccel);
     }while (!XRemap_accel_IsDone(&remapAccel));

	return 0;
}
