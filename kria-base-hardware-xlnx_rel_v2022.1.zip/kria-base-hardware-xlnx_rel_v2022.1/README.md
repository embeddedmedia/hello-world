<h1 align="center">KRIA SOM BASE HARDWARE DESGIN</h1>

## Introduction
This repository contains the Kria SOM base hardware projects. It contains various tcl files which can be used to generate XSA for the required starter kit.


## To generate an XSA for starter kits
1. cd to <part_name>_starter_kits/<starter_kit_name>
2. Run command 
	make xsa  
   Note you can also pass arguments to the make command
	make xsa JOBS=<num> PROJ_NAME=<proj_name>

# License

(C) Copyright 2020 - 2021 Xilinx, Inc.\
SPDX-License-Identifier: Apache-2.0
